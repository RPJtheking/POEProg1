﻿using System;
using System;
using System.Collections.Generic;
using System.Collections.Generic;
using System.Linq;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

public class Recipe
{
    public string Name { get; set; }
    public List<Ingredient> Ingredients { get; set; }
    public List<Step> Steps { get; set; }
    public double ScaleFactor { get; private set; }

    public event Action<string> OnCaloriesExceeded; // Delegate for notification

    public Recipe(string name)
    {
        Name = name;
        Ingredients = new List<Ingredient>();
        Steps = new List<Step>();
        ScaleFactor = 1.0; // Default scale factor
    }

    public void AddIngredient(Ingredient ingredient)
    {
        Ingredients.Add(ingredient);
        CheckCalories(); // Check if calories exceed the threshold when adding a new ingredient
    }

    public void AddStep(Step step)
    {
        Steps.Add(step);
    }

    public void Scale(double factor)
    {
        ScaleFactor = factor;
        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity *= factor;
        }
    }

    public void ResetScale()
    {
        foreach (var ingredient in Ingredients)
        {
            ingredient.Quantity /= ScaleFactor; // Reset by reversing the scale
        }
        ScaleFactor = 1.0;
    }

    public void CheckCalories()
    {
        double totalCalories = Ingredients.Sum(i => i.Calories * i.Quantity);
        if (totalCalories > 300)
        {
            OnCaloriesExceeded?.Invoke($"Warning: Total calories for '{Name}' exceed 300. Total: {totalCalories}");
        }
    }

    public override string ToString()
    {
        string result = $"Recipe: {Name}\nIngredients:\n";
        foreach (var ingredient in Ingredients)
        {
            result += $"- {ingredient}\n";
        }

        result += "\nSteps:\n";
        foreach (var step in Steps)
        {
            result += $"- {step}\n";
        }

        return result;
    }
}
