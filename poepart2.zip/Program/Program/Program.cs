﻿using System;
using System.Collections.Generic;

class Program
{
    static List<Recipe> recipeList = new List<Recipe>(); // to store multiple recipes

    static void Main(string[] args)
    {
        string input;
        while (true)
        {
            Console.WriteLine("Choose an option:");
            Console.WriteLine("1. Add a new recipe");
            Console.WriteLine("2. List all recipes");
            Console.WriteLine("3. Display a recipe");
            Console.WriteLine("4. Scale a recipe");
            Console.WriteLine("5. Reset scale");
            Console.WriteLine("6. Clear all data");
            Console.WriteLine("7. Exit");

            input = Console.ReadLine();

            switch (input)
            {
                case "1":
                    AddNewRecipe();
                    break;
                case "2":
                    ListRecipes();
                    break;
                case "3":
                    DisplayRecipe();
                    break;
                case "4":
                    ScaleRecipe();
                    break;
                case "5":
                    ResetScale();
                    break;
                case "6":
                    recipeList.Clear();
                    Console.WriteLine("All data cleared.");
                    break;
                case "7":
                    Console.WriteLine("Exiting...");
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }

    static void AddNewRecipe()
    {
        Console.Write("Enter the name of the recipe: ");
        string recipeName = Console.ReadLine();

        var recipe = new Recipe(recipeName);
        recipe.OnCaloriesExceeded += (msg) => Console.WriteLine(msg); // Assign delegate handler

        Console.Write("Enter the number of ingredients: ");
        int ingredientCount = int.Parse(Console.ReadLine());

        for (int i = 0; i < ingredientCount; i++)
        {
            Console.Write("Enter ingredient name: ");
            string name = Console.ReadLine();

            Console.Write("Enter ingredient quantity: ");
            double quantity = double.Parse(Console.ReadLine());

            Console.Write("Enter unit of measurement: ");
            string unit = Console.ReadLine();

            Console.Write("Enter calories for the ingredient: ");
            double calories = double.Parse(Console.ReadLine());

            Console.Write("Enter the food group for the ingredient: ");
            string foodGroup = Console.ReadLine();

            var ingredient = new Ingredient(name, quantity, unit, calories, foodGroup);
            recipe.AddIngredient(ingredient);
        }

        Console.Write("Enter the number of steps: ");
        int stepCount = int.Parse(Console.ReadLine());

        for (int i = 0; i < stepCount; i++)
        {
            Console.Write("Enter step description: ");
            string description = Console.ReadLine();
            var step = new Step(description);
            recipe.AddStep(step);
        }

        recipeList.Add(recipe);
    }

    static void ListRecipes()
    {
        Console.WriteLine("Recipes:");
        foreach (var recipe in recipeList)
        {
            Console.WriteLine(recipe.Name);
        }
    }

    static void DisplayRecipe()
    {
        Console.Write("Enter the recipe name to display: ");
        string recipeName = Console.ReadLine();

        var recipe = recipeList.Find(r => r.Name == recipeName);

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
        }
        else
        {
            Console.WriteLine(recipe);
        }
    }

    static void ScaleRecipe()
    {
        Console.Write("Enter the recipe name to scale: ");
        string recipeName = Console.ReadLine();

        var recipe = recipeList.Find(r => r.Name == recipeName);

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
        }
        else
        {
            Console.Write("Enter the scale factor (0.5, 2, 3): ");
            double scaleFactor = double.Parse(Console.ReadLine());
            recipe.Scale(scaleFactor);
            Console.WriteLine($"Scaled '{recipeName}' by {scaleFactor}.");
        }
    }

    static void ResetScale()
    {
        Console.Write("Enter the recipe name to reset: ");
        string recipeName = Console.ReadLine();

        var recipe = recipeList.Find(r => r.Name == recipeName);

        if (recipe == null)
        {
            Console.WriteLine("Recipe not found.");
        }
        else
        {
            recipe.ResetScale();
            Console.WriteLine($"Reset scale for '{recipeName}'.");
        }
    }
}